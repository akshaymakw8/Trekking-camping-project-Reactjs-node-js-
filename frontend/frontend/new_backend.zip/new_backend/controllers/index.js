module.exports.userController = require("./user.controller");
module.exports.tourController=require('./tour.controller');
module.exports.bookingController=require('./booking.controller');
module.exports.feedbackController=require('./feedback.controller');

