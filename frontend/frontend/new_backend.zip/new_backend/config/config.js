module.exports = {
  database: {
    database: "test",
  },
};
