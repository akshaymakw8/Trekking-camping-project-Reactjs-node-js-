exports.SECRETKEY = "register-backend-secret";
exports.PORT = 8080;
exports.HOST = "localhost";
exports.FILE_PATH = "public";
exports.BASE_API_URL = "/api/v1/";
