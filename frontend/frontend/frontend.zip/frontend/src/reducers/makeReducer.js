const makeReducer = (state = {}, action) => {
    switch (action.type) {
        default:
            return state
    }
};

export default makeReducer;