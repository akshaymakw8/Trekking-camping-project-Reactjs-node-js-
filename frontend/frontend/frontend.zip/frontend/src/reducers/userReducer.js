const userReducer = (state = {}, action) => {
    switch (action.type) {
        default:
            return state
    }
};

export default userReducer;