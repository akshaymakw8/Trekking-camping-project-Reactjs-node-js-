const tourReducer = (state = {}, action) => {
    switch (action.type) {
        default:
            return state
    }
};

export default tourReducer;