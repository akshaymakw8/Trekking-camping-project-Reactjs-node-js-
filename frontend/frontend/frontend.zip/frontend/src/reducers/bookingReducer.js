const bookingReducer = (state = {}, action) => {
    switch (action.type) {
        default:
            return state
    }
};

export default bookingReducer;