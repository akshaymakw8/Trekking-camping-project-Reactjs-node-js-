import React from "react";

const SearchResultList = () => {
    return <dv>SearchResultList</dv>;
};

export default SearchResultList;